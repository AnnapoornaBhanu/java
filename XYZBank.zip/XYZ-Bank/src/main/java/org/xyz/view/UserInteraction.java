package org.xyz.view;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import org.xyz.model.Account;
import org.xyz.model.Address;
import org.xyz.model.Customer;
import org.xyz.util.Utility;

public class UserInteraction {

	Scanner scan=new Scanner(System.in);
	
	
		public Customer getCustomerDetails()
		{
			Customer customer=new Customer();
			Address address=new Address();
			String option;
			customer.setCustomerID(Utility.generateCustomerID());
			//System.out.println(customer.getCustomerID());
			System.out.print("Enter First Name:");
			customer.setFirstName(Utility.promptName());
			System.out.print("Enter Last Name:");
			customer.setLastName(Utility.promptName());
			customer.setEmail(Utility.promptEmail());
			customer.setMobile(Utility.promptMobile());
			customer.setDateOfBirth(Utility.promptDOB());
			customer.setAddress(getAddressDetails());
			Set<Account> account1=new HashSet<>();
			do {
			account1.add(getAccountDetails(customer));
			System.out.println("Do you wish to add another account");
			option=scan.next();
			}while(option.charAt(0)=='Y'|| option.charAt(0)=='y');
			customer.setAccount(account1);
			return customer;
		}
			
			
			
		
		public Address getAddressDetails()
		{
			Address address= new Address();
			
			address.setAddressLine1(Utility.promptAddressLine1());
			address.setAddressLine2(Utility.promptAddressLine2());
			address.setCity(Utility.promptCity());
			address.setState(Utility.promptState());
			address.setPincode(Utility.promptPincode());
			return address;
		}
		
		public Customer findCustomer(List<Customer> customers, int customerID)
		{
			
			
			
			int i,j;
			for(i=0;i<customers.size();i++)
			{
				if(customerID==customers.get(i).getCustomerID())
					break;
				else continue;
			}
			return customers.get(i);
		}
		
		public Account addAccount(Customer customer) {
			Account account=new Account();
			//Customer customer=findCustomer(customers);
			int j=customer.getAccount().size();
			System.out.println(j);
			if(j<4)
			{
				
			account=getAccountDetails(customer);
			
			}
			return account;
			// TODO Auto-generated method stub
			
		}
		
		
		public  Account getAccountDetails(Customer customer)
		{
			//Set<Account> accountSet=new HashSet<>();
			
			Account account=new Account();
			account.setAccountNo(Utility.generateAccountNo());
			account.setAccountType(Utility.promptAccountType());
			account.setOpeningDate(LocalDate.now());
			account.setOpeningBalance(Utility.promptOpeningBalance());
			account.setDescription(Utility.promptAccDescription(account.getAccountType()));
		
				
				
				//System.out.println(customer);
			return account;
		}
		
		
		public void printError(String message) {
			System.out.println(message);
			
		}
		
		public void printCustomers(List<Customer> customers) {
			System.out.println("CustomerId\tCustomerName\tEmailId\t\tMobile\t\tAccounts\tAccountType");
			System.out.println("-----------------------------------------------------------------------------");
			
			for(Customer customer:customers) {
				System.out.print(customer.getCustomerID()
						+"\t\t"+customer.getFirstName()+" " + customer.getLastName()
						+"\t"+ customer.getEmail() + "\t" + customer.getMobile() +"\t");
				Set<Account> account=customer.getAccount();
				Iterator<Account> iterator=account.iterator();
				System.out.println();
				while(iterator.hasNext())
				{
					Account account1=iterator.next();
					System.out.println("\t\t\t\t\t\t\t\t"+account1.getAccountNo()+"\t\t"+account1.getAccountType());
				}
				System.out.println();
				
			}
			
		}


		
		
	}



