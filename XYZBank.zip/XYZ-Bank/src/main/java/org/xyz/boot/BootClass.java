package org.xyz.boot;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import org.xyz.model.Account;
import org.xyz.model.Customer;
import org.xyz.service.CustomerServiceImpl;
import org.xyz.service.ICustomerService;
import org.xyz.view.UserInteraction;

public class BootClass {
	static Scanner scan=new Scanner(System.in);
	
	public static void main(String[] args)
	{	
		ICustomerService customerService=new CustomerServiceImpl();		
		UserInteraction userInteraction=new UserInteraction();
		List<Customer> customers = null;
		
		customers= customerService.getAllCustomers();
		String option = null;
		do {
		System.out.println("1.Create new customer \t2. List all customers\t3. Create Account\nEnter your choice");
		int choice=scan.nextInt();
		switch(choice)
		{
		case 1:

			int count=customerService.getAllCustomers().size();
			
			Customer customer=userInteraction.getCustomerDetails();
			customerService.createCustomer(customer);
			
			
			if(count==customerService.getAllCustomers().size())
				userInteraction.printError("Customer Creation Error! Please Try Again!");
			
			break;
			
		case 2:
					
			userInteraction.printCustomers(customers);
			
			
			break;
		case 3:
			Account account=new Account();
			System.out.println("Enter the customer ID");
			int customerID=scan.nextInt();
			
			Customer customer1=userInteraction.findCustomer(customers, customerID);
			account=userInteraction.addAccount(customer1);
			customerService.addAccountDetails(customer1,account);
			
		}
		System.out.println("Do you wish to contine?[y|n]:");
		option=scan.next();
		}while(option.charAt(0)=='Y'|| option.charAt(0)=='y');
	}
}
