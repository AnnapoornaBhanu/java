package org.xyz.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.xyz.model.Account;
import org.xyz.model.Address;
import org.xyz.model.Customer;

public class CustomerDaoImp implements ICustomerDao {
	
	List<Customer> customers=dummyDB();
	
	private static List<Customer> dummyDB(){
		List<Customer> customers=new ArrayList<>();
		
		Address address=new Address("23,west Car St", "2nd St", "Chennai", "TN", 234442);
		customers.add(new Customer(123,"Jack","Thomson", LocalDate.of(1991, 01, 23),
				"jack@gmail.com","8890912345",address));
		
		Address address1=new Address("North Avnnue", "2nd Cross St", "Hyderabad", "AP", 657657);
		customers.add(new Customer(1090,"Tom","Jerry", LocalDate.of(1987, 12, 23),
				"tom@gmail.com","9090912345",address1));
		
		return customers;
	}

	@Override
	public List<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		
		return customers;
	}

	@Override
	public void createCustomer(Customer customer) {
		// TODO Auto-generated method stub
		customers.add(customer);
	}

	@Override
	public void addAccountDetails(Customer customer, Account account) {
		// TODO Auto-generated method stub
		customer.getAccount().add(account);
		//customer.getAccount(account);
		
	}

}
