package org.xyz.dao;

import java.util.List;

import org.xyz.model.Account;
import org.xyz.model.Customer;

public interface ICustomerDao {
	public abstract List<Customer> getAllCustomers();
	public abstract void createCustomer(Customer customer);
	//public abstract void creatAccount(Account account);
	public abstract void addAccountDetails(Customer customers, Account account);
}
