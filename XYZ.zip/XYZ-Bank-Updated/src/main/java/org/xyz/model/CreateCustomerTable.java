package org.xyz.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class CreateCustomerTable {

	
	public void createCustomerTable()
	{

		String sql="create table Customer(customerID int primary key,firstName varchar(25),lastName varchar(25),dateOfBirth date,mobile varchar(10), email varchar(30) )";
	
		
		try(Connection connection=getDbConnection())
		{
			PreparedStatement statement=connection.prepareStatement(sql);
			boolean flag=statement.execute();
		
			
			if(flag==false)
			{
				System.out.println("Table Creation Done!");
			}
			else
			{
				System.out.println("Table Creation failed");
			}
			
			
		}
		catch( SQLException e)
		{
			e.printStackTrace();
		}
		
	}
	
	private Connection getDbConnection()
	{ 
		Connection connection =null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection =DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "India123");
			return connection;
		}
		catch(ClassNotFoundException | SQLException e)
		{
			e.printStackTrace();
		}
		return null;
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CreateCustomerTable customerTable=new CreateCustomerTable();
		customerTable.createCustomerTable();

	}
}
