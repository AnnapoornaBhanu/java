package org.xyz.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.xyz.model.Account;
import org.xyz.model.Customer;
import org.xyz.model.Transaction;



public class CustomerDBImpl implements ICustomerDao{
	
	private Connection getDbConnection()
	{ 
		Connection connection =null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection =DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "India123");
			return connection;
		}
		catch(ClassNotFoundException | SQLException e)
		{
			e.printStackTrace();
		}
		return null;
	}
	
	

	@Override
	public List<Customer> getAllCustomers() {
		List<Customer> customers=new ArrayList<>();
		
		String sql="select * from Customer";
		try(Connection conn=getDbConnection()) {
			PreparedStatement pst=conn.prepareStatement(sql);
			ResultSet resultSet= pst.executeQuery();
			while(resultSet.next()) {
				Customer customer=new Customer();
				customer.setCustomerID(resultSet.getInt(1));
				customer.setFirstName(resultSet.getString("firstName"));
				customer.setLastName(resultSet.getString("lastName"));
				customer.setDateOfBirth(resultSet.getDate(4).toLocalDate());
				customer.setMobile(resultSet.getString(5));
				customer.setEmail(resultSet.getString(6));
				customers.add(customer);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		return customers;
	}

	@Override
	public void createCustomer(Customer customer) {

		String sql="insert into customer values(?,?,?,?,?)";
		
		try(Connection connection=getDbConnection())
		{
			PreparedStatement statement=connection.prepareStatement(sql);
			statement.setInt(1, customer.getCustomerID());
			statement.setString(2, customer.getFirstName());
			statement.setString(3, customer.getLastName());
			statement.setDate(4, java.sql.Date.valueOf(customer.getDateOfBirth()));
			statement.setString(5, customer.getMobile());
			statement.setString(6, customer.getEmail());
			
			int flag=statement.executeUpdate();
		
			
			if(flag>0)
			{
				System.out.println("Insertion Done!");
			}
			else
			{
				System.out.println("Insertion failed");
			}
			
			
		}
		catch( SQLException e)
		{
			e.printStackTrace();
		}
		
	}

	@Override
	public void addAccountDetails(Customer customers, Account account) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addTransactionDetails(Transaction transaction, Customer customer) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Map<Customer, List<Transaction>> getTransactionDetails() {
		// TODO Auto-generated method stub
		return null;
	}

}
