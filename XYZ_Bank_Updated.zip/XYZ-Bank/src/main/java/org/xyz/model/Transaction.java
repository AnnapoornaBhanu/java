package org.xyz.model;

import java.time.LocalDate;

public class Transaction {

	private long transactionID;
	private LocalDate transactionDate;
	private double amount;
	private String credit_Debit;
	private long fromAccount;
	private long toAccount;
	
	
	
	
	public Transaction() {
		super();
	}
	public Transaction(long transactionID, LocalDate transactionDate, double amount, String credit_Debit,
			long fromAccount, long toAccount) {
		super();
		this.transactionID = transactionID;
		this.transactionDate = transactionDate;
		this.amount = amount;
		this.credit_Debit = credit_Debit;
		this.fromAccount = fromAccount;
		this.toAccount = toAccount;
		
	}
	public long getTransactionID() {
		return transactionID;
	}
	public void setTransactionID(long transactionID) {
		this.transactionID = transactionID;
	}
	public LocalDate getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(LocalDate transactionDate) {
		this.transactionDate = transactionDate;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getCredit_Debit() {
		return credit_Debit;
	}
	public void setCredit_Debit(String credit_Debit) {
		this.credit_Debit = credit_Debit;
	}
	public long getFromAccount() {
		return fromAccount;
	}
	public void setFromAccount(long fromAccount) {
		this.fromAccount = fromAccount;
	}
	public long getToAccount() {
		return toAccount;
	}
	public void setToAccount(long toAccount) {
		this.toAccount = toAccount;
	}
	@Override
	public String toString() {
		return "Transaction [transactionID=" + transactionID + ", transactionDate=" + transactionDate + ", amount="
				+ amount + ", credit_Debit=" + credit_Debit + ", fromAccount=" + fromAccount + ", toAccount="
				+ toAccount + "]";
	}
	
	
}
