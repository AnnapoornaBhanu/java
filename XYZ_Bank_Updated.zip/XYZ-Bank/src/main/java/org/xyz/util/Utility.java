package org.xyz.util;

import java.time.LocalDate;
import java.util.Scanner;

import org.xyz.model.AccountType;

public class Utility {

	static Scanner scan=new Scanner(System.in);
	public static int promptOpeningBalance()
	{
		int balance;
		System.out.println("Enter the opening balance");
		balance=scan.nextInt();
		return balance;
	}
	
	
	public static int generateCustomerID()
	{
		int x=(int)(Math.random()*1000);
		return x;
	}
	
	public static String promptName()
	{
		String name;
		boolean b=false;
		do {
		name=scan.next();
		b=name.matches("[A-Za-z]{3,}");
		if(!b)
		{
			System.out.println("Name can contain only alphabets and length should be atleast 3 characters!");
		}
		}
		while(!b);
		
		return name;
	}
	
	public static LocalDate promptDOB() {
		
		// TODO Auto-generated method stub
		String dob;
		Integer date,month,year;
		boolean b=false;
		
		do {
		System.out.println("Enter date of birth dd/mm/yyyy");
		dob=scan.next();
		
		date=Integer.parseInt(dob.substring(0, 2));
		month=Integer.parseInt(dob.substring(3, 5));
		year=Integer.parseInt(dob.substring(6, 10));
		//System.out.println(year);
		if(dob.charAt(2)!='/'|| dob.charAt(5)!='/'|| ( date<1 && date>31) || (month<0 && month>12))
		{
			System.out.println("Follow the format dd/mm/yyyy");
			b=false;
		}
		else b=true;
		}
		while(!b);
		scan.nextLine();
		return LocalDate.of(year, month, date);
		
		
	}

	public static String promptMobile() {
		// TODO Auto-generated method stub
		String mobile;
		boolean b=false;
		do {
			System.out.println("Enter your mobile No.:");
		mobile=scan.next();
		
		b=mobile.matches("[0-9]{10}");
		if(!b)
		{
			System.out.println("Invalid Mobile Number!");
		}
		}
		while(!b);
	return mobile;
	}

	public static String promptEmail()
	{
		
		String email;
		boolean b=false;
		do {
			System.out.println("Enter your email ID:");
		email=scan.next();
		
		b=email.matches("[A-za-z0-9]+[@]{1}[a-z]+[.]{1}[a-z]{2,3}");
		if(!b)
		{
			System.out.println("Invalid email ID!");
		}
		}
		while(!b);
		return email;
	}

	public static String promptAddressLine1() {
		// TODO Auto-generated method stub
		
		String address;
		System.out.println("Address line1:");
		address=scan.nextLine();
		//scan.next();
		return address;
		
	}
	
	public static String promptAddressLine2() {
		// TODO Auto-generated method stub
		
		String address;
		System.out.println("Address line2:");
		address=scan.nextLine();
		//scan.nextLine();
		return address;
	}
	public static String promptCity() {
			System.out.println("City:");
			String city;
			city=scan.next();
			//scan.next();
		return city;
	}

	public static String promptState() {
		// TODO Auto-generated method stub
		String state;
		System.out.println("State:");
		state=scan.next();
		
		return state;
	}

	public static int promptPincode() {
		// TODO Auto-generated method stub
		Integer pincode;
		boolean b=false;
		do {
			System.out.println("Pincode:");
			pincode=scan.nextInt();
			if(pincode<100000 || pincode>1000000)
			{
				System.out.println("Invalid pincode");
				
			}
			else b=true;
		}while(!b);
		return pincode;
	}

	public static long generateAccountNo() {
		// TODO Auto-generated method stub
		
		long x=(long)(Math.random()*250000);
		return x;
		
	}

	public static AccountType promptAccountType() {
		// TODO Auto-generated method stub
		AccountType accountType=AccountType.SAVINGS;
		boolean b=false;
		int a;
		do {
		System.out.println("Choose the type of account:\n 1.Savings\t2.RD\t3.FD\t4.Current");
		a=scan.nextInt();
		if(a<1 || a>4) System.out.println("Enter a value between 1 and 4");
		else b=true;
		}while(!b);
		switch (a)
		{
		case 1:accountType= accountType.SAVINGS; break;
		case 2:accountType= accountType.RD; break;
		case 3:accountType= accountType.FD; break;
		case 4: accountType= accountType.CURRENT; break;
		
		}
		return accountType;
		
	}


	public static String promptAccDescription(AccountType accountType) {
		// TODO Auto-generated method stub
		if(accountType==AccountType.SAVINGS)
			return "Savings account";
		else if(accountType==AccountType.FD)
			return "Fixed Deposit account";
		else if(accountType==AccountType.RD)
			return "RD account";
		else
			return "Current Account";
	}


	public static long createTransactionID() {
		// TODO Auto-generated method stub
		
		int x=(int)(Math.random()*1000000);
		return x;
		
	}

	
	
}
	

