package org.xyz.view;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import org.xyz.boot.BootClass;
import org.xyz.model.Account;
import org.xyz.model.Address;
import org.xyz.model.Customer;
import org.xyz.model.Transaction;
import org.xyz.util.Utility;

public class UserInteraction {

	Scanner scan=new Scanner(System.in);
	
	
		public Customer getCustomerDetails()
		{
			Customer customer=new Customer();
			Address address=new Address();
			String option;
			customer.setCustomerID(Utility.generateCustomerID());
			//System.out.println(customer.getCustomerID());
			System.out.print("Enter First Name:");
			customer.setFirstName(Utility.promptName());
			System.out.print("Enter Last Name:");
			customer.setLastName(Utility.promptName());
			customer.setEmail(Utility.promptEmail());
			customer.setMobile(Utility.promptMobile());
			customer.setDateOfBirth(Utility.promptDOB());
			customer.setAddress(getAddressDetails());
			Set<Account> account1=new HashSet<>();
			
			do {
			account1.add(getAccountDetails(customer));
			System.out.println("Do you wish to add another account");
			option=scan.next();
			}while(option.charAt(0)=='Y'|| option.charAt(0)=='y');
			customer.setAccount(account1);
			return customer;
		}
			
		
		public Address getAddressDetails()
		{
			Address address= new Address();
			
			address.setAddressLine1(Utility.promptAddressLine1());
			address.setAddressLine2(Utility.promptAddressLine2());
			address.setCity(Utility.promptCity());
			address.setState(Utility.promptState());
			address.setPincode(Utility.promptPincode());
			return address;
		}
		
		
		public Customer validateCustomerID(List<Customer> customers)
		
		{
			Customer customer1=null;
			boolean b=false;
			do{
				System.out.println("Enter the customer ID");
			int customerID=scan.nextInt();
			Customer cust=findCustomer(customers, customerID);
			if(cust!=null)
			{
				b=true;
				customer1=cust;
				
			}
			else 
				System.out.println("Invalid customer ID! Please try again");
		}while(!b);
			return customer1;
		}
		
		
		public Customer findCustomer(List<Customer> customers, int customerID)
		{
			int i,j;
			for(i=0;i<customers.size();i++)
			{
				if(customerID==customers.get(i).getCustomerID())
					break;
				
			}
			if(i==customers.size())
				return null;
			else return customers.get(i);
		}
				
		
		public Account addAccount(Customer customer) {
			Account account=new Account();
			//Customer customer=findCustomer(customers);
			int j=customer.getAccount().size();
			System.out.println(j);
			if(j<4)
			{
				
			account=getAccountDetails(customer);
			System.out.println("Account Number="+account.getAccountNo()+" Account Type="+account.getAccountType());
			return account;			
			}
			else 
			{
				System.out.println("You already have four accounts");
				return null;
			}
				
			
		}
				
		
		public  Account getAccountDetails(Customer customer)
		{
			
			Account account=new Account();
			account.setAccountNo(Utility.generateAccountNo());
			account.setAccountType(Utility.promptAccountType());
			account.setOpeningDate(LocalDate.now());
			account.setOpeningBalance(Utility.promptOpeningBalance());
			account.setDescription(Utility.promptAccDescription(account.getAccountType()));
		
			return account;
		}
			
		
		public void printError(String message) {
			System.out.println(message);
			
		}
		
		
		public void printCustomers(List<Customer> customers) {
			System.out.println("CustomerId\tCustomerName\tEmailId\t\tMobile\t\tAccounts\tAccountType");
			System.out.println("-----------------------------------------------------------------------------");
			
			for(Customer customer:customers) {
				System.out.print(customer.getCustomerID()
						+"\t\t"+customer.getFirstName()+" " + customer.getLastName()
						+"\t"+ customer.getEmail() + "\t" + customer.getMobile() +"\t");
				Set<Account> account=customer.getAccount();
				Iterator<Account> iterator=account.iterator();
				System.out.println();
				while(iterator.hasNext())
				{
					Account account1=iterator.next();
					System.out.println("\t\t\t\t\t\t\t\t"+account1.getAccountNo()+"\t\t"+account1.getAccountType());
				}
				System.out.println();
				
			}
			
		}


		public Account checkAccountNumber(Customer customer1)
		
		{
			boolean b=false;
			Set<Account> account=customer1.getAccount();
			if(customer1.getAccount().size()==0) return null;
			else{
			do{
				System.out.println("Enter the account number from which you wish to make a transaction");
				long accountNo=scan.nextLong();
				
				
				Iterator<Account> iterator=account.iterator();
				System.out.println();
				while(iterator.hasNext())
				{
					Account account1=iterator.next();
					if(account1.getAccountNo()==accountNo)
					{
						b=true;
						return account1;
						
					}
					
				}
				System.out.println("Account Number Invalid! Please try Again!");
			}while(!b);
			return null;
		}
		}

		
		public Transaction debitOrCredit(Account account, double currentBalance) {
			int choice;
			Transaction transaction=null;
			double amount;
			System.out.println("1. Debit\t 2. Credit\nEnter your choice");
			choice=scan.nextInt();
			
			switch(choice)
			{
			case 1:
				System.out.println("Enter the amount to withdraw");
				amount=scan.nextInt();
				if(amount>currentBalance)
					System.out.println("Amount entered is greater than available balance");
				else
				{
					//calculateCurrentBalance("Debit",currentBalance,amount);
					BootClass.fromcurrentBalance-=amount;
					transaction=updateTransactionDetails(amount,account,"Debit");
					System.out.println("Current Balance="+BootClass.fromcurrentBalance);
				}
				
				break;
			case 2:
				System.out.println("Enter the amount to deposit");
				amount=scan.nextInt();
				BootClass.fromcurrentBalance+=amount;
				transaction=updateTransactionDetails(amount,account,"Credit");
				System.out.println("Current Balance="+BootClass.fromcurrentBalance);
				break;
			
			}
			return transaction;
		}


		private Transaction updateTransactionDetails(double amount,Account account,String creditOrDebit) {
			// TODO Auto-generated method stub
			
			Transaction transaction= new Transaction();
			transaction.setFromAccount(account.getAccountNo());
			transaction.setToAccount(account.getAccountNo());
			transaction.setAmount(amount);
			transaction.setCredit_Debit(creditOrDebit);
			transaction.setTransactionDate(LocalDate.now());
			transaction.setTransactionID(Utility.createTransactionID());
			return transaction;
			
		}
		
		private Transaction updateTransactionDetails(double amount,Account fromAccount, Account toAccount,String creditOrDebit) {
			// TODO Auto-generated method stub
			
			Transaction transaction= new Transaction();
			transaction.setFromAccount(fromAccount.getAccountNo());
			transaction.setToAccount(toAccount.getAccountNo());
			transaction.setAmount(amount);
			transaction.setCredit_Debit(creditOrDebit);
			transaction.setTransactionDate(LocalDate.now());
			transaction.setTransactionID(Utility.createTransactionID());
			return transaction;
			
		}

		public Customer getToAccountCustomer(List<Customer> customers, long toAccountNo) 
		{
			
			Customer customer;
			Set<Account> accounts=new HashSet<>();
			Account account;
			
			for(int i=0;i<customers.size();i++)
			{
				customer=customers.get(i);
				
				for(int j=0;j<customer.getAccount().size();j++)
				{
					accounts=customer.getAccount();
					//System.out.println(j);
					Iterator<Account> iterator=accounts.iterator();
					while(iterator.hasNext())
						
					{
						account=iterator.next();
						if(account.getAccountNo()==toAccountNo)
							return customer;
					}
				}
			}
			
			
			
			return null;
		}
		
		public Account checkToAccountNumber(Customer customer, long toAccountNo) 
		{
				
			Set<Account> accounts=customer.getAccount();
			Account account;
			System.out.println(customer.getAccount().size());
				for(int j=0;j<customer.getAccount().size();j++)
				{
					Iterator<Account> iterator=accounts.iterator();
					while(iterator.hasNext())
						
					{
						account=iterator.next();
						if(account.getAccountNo()==toAccountNo)
							return account;
					}
				}
				return null;
		}
		
		


		public Transaction fromFundTransfer(Account fromAccount, Account toAccount, double currentBalance, double amount) {
			Transaction transaction;
		
			
			if(amount>currentBalance)
			{
				System.out.println("Amount entered is greater than available balance");
				return null;
			}
			else
			{
				//calculateCurrentBalance("Debit",currentBalance,amount);
				//fromaccount.getOeningBalance()-amount;
				//fromAccount.setOpeningBalance();
				transaction=updateTransactionDetails(amount,fromAccount,toAccount,"FundTransfer");
				//System.out.println("Current Balance="+BootClass.fromcurrentBalance);
			}
			return transaction;
			
			
		}


		public Transaction toFundTransfer(Account fromAccount, Account toAccount, double currentBalance, double amount) {
			// TODO Auto-generated method stub
			Transaction transaction;
			BootClass.fromcurrentBalance+=amount;
			transaction=updateTransactionDetails(amount,fromAccount,toAccount,"FundTransfer");
			//System.out.println("Current Balance="+BootClass.fromcurrentBalance);
			
			
			return transaction;
		}


		
}
			
			
		

