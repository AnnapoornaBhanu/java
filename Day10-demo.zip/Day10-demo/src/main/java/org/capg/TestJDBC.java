package org.capg;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;



public class TestJDBC {

		public static void main(String[] args)
		{
			//load driver class
			
			try (Connection connection =DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "India123")){
				Class.forName("com.mysql.jdbc.Driver");
				
				
				String sql="create table employee(empid int primary key,firstName varchar(25) not null, lastName varchar(25), salary numeric(8,2), empdoj date)"; 
				Statement statement=connection.createStatement();
				boolean flag=statement.execute(sql);
				if(flag==true)
				{
					System.out.println("Error in table creation");
				}
				else
				{
					System.out.println("Table created successfully");
				}
			
			}
			catch(ClassNotFoundException | SQLException e)
			{
				e.printStackTrace();
			}
			
		
		}
}
