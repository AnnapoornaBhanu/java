package org.capg;

import java.time.LocalDate;
import java.util.List;

public interface EmployeeDao {
	
	public void createEmployee(Employee employee);

	public List<Employee> getAllEmployees();

	void deleteEmployee(int employeeId);

	public Employee findEmployee(int empID);

	void updateEmployeeLast(int empID, String lastName);

	void updateEmployeeSalary(int empID, Double salary);

	void updateEmployeeFirst(int empID, String firstName);

	void updateEmployeeDOJ(int empID, LocalDate date);

	public Employee callProcedure(int employeeId);

	public void callBulkInsertion();

}
