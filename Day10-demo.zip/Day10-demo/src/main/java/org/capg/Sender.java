package org.capg;

public class Sender <T,R> {
	private T message;
	private R desc;
	
	public void setMessage(T message)
	{
		this.message=message;
	}
	
	public void setDesc(R desc)
	{
		this.desc=desc;
	}
}
