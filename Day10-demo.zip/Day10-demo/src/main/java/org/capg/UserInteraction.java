package org.capg;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

import org.capg.Employee;

public class UserInteraction {
	
	Scanner scan=new Scanner(System.in);
	Employee employee=new Employee();
	
	
	public int promptEmployeeID() {
		System.out.println("Enter Employee Id:");
		return scan.nextInt();
	}
	public Employee createCustomer() {
		
		System.out.println("Enter the EmployeeID");
		employee.setEmpID(scan.nextInt());
		System.out.println("Enter the First Name");
		employee.setFirstName(scan.next());
		System.out.println("Enter the Last Name");
		employee.setLastName(scan.next());
		System.out.println("Enter Employee's Salary");
		employee.setSalary(scan.nextDouble());
		System.out.println("Enter the Date of Joining [yyyy-mm-dd]");
		String date=scan.next();
		int a=Integer.parseInt(date.substring(0, 4));
		int b=Integer.parseInt(date.substring(5,7));
		int c=Integer.parseInt(date.substring(8,9));
		employee.setEmpdoj(LocalDate.of(a, b, c));		
		return employee;
		
		
	}

	public void updateEmployee(int empID) {
		EmployeeDao dao=new EmployeeDaoImp();
		
		System.out.println("Enter the field you wish to update.\n1.First NAme\t2.Last NAme\t3.Salary\t4.Date of Joining");
		int choice=scan.nextInt();
		switch(choice)
		{
		case 1:
			System.out.println("Enter the First Name");
			String firstName=scan.next();
			dao.updateEmployeeFirst(empID, firstName);
			break;
		case 2:
			System.out.println("Enter the Last Name");
			String lastName=scan.next();
			dao.updateEmployeeLast(empID, lastName);
			break;
		case 3:
			System.out.println("Enter the Salary");
			Double salary=scan.nextDouble();
			dao.updateEmployeeSalary(empID, salary);
			break;
		case 4:
			System.out.println("Enter the Date of Joining");
			String date=scan.next();
			int a=Integer.parseInt(date.substring(0, 4));
			int b=Integer.parseInt(date.substring(5,7));
			int c=Integer.parseInt(date.substring(8,9));
			//employee.setEmpdoj(LocalDate.of(a, b, c));	
			LocalDate date1=LocalDate.of(a, b, c);
			dao.updateEmployeeDOJ(empID, date1);
			break;
			
		}
		// TODO Auto-generated method stub
	}




	
		
		public void printAllEmployees(List<Employee> employees) {
			System.out.println("EmployeeId\tFirstName\tLastName\tSalary\tDateOfjoining");
			for(Employee employee:employees)
				System.out.println(employee.getEmpID() +"\t"
						+employee.getFirstName()+"\t" 
						+employee.getLastName()+"\t" 
						+employee.getSalary()+"\t" 
						+employee.getEmpdoj() );
			
		
		// TODO Auto-generated method stub
		
	}

		public void printEmployee(Employee employee) {
			// TODO Auto-generated method stub
			System.out.println("EmployeeId\tFirstName\tLastName\tSalary\tDateOfjoining");
			System.out.println(employee.getEmpID() +"\t"
					+employee.getFirstName()+"\t" 
					+employee.getLastName()+"\t" 
					+employee.getSalary()+"\t" 
					+employee.getEmpdoj() );
		
		}}
