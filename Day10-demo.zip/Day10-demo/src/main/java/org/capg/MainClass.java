package org.capg;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Sender<String,Integer> str=new Sender();
		str.setMessage("Hello");
		str.setDesc(10);
		
		Sender<Integer,Integer> str1=new Sender();
		str1.setMessage(1);
		str1.setDesc(10);
	}

}
