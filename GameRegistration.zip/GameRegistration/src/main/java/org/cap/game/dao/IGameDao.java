package org.cap.game.dao;

import org.cap.game.model.Registration;

public interface IGameDao {

		public boolean addCustomer(Registration registration);
}
