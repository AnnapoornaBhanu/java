package org.cap.game.dao;

import org.cap.game.model.Registration;

public class GameDaoImp implements IGameDao{

	@Override
	public boolean addCustomer(Registration registration) {
		// TODO Auto-generated method stub
		
		
		return false;
	}

}
