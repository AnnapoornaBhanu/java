package org.cap.game.model;

public class Registration {
	
	private int registrationID;
	private String customerName;
	private String mobileNo;
	private int age;
	private double registrationFee=1000;
	private double actualRegistrationFee;
	
	public Registration()
	
	{
		
	}
	
	public Registration(String customerName, String mobileNo, int age, 
			double actualRegistrationFee) {
		super();
		this.customerName = customerName;
		this.mobileNo = mobileNo;
		this.age = age;
		//this.registrationFee = registrationFee;
		this.actualRegistrationFee = actualRegistrationFee;
	}
	public int getRegistrationID() {
		return registrationID;
	}
	public void setRegistrationID(int registrationID) {
		this.registrationID = registrationID;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public double getRegistrationFee() {
		return registrationFee;
	}
	
	public double getActualRegistrationFee() {
		return actualRegistrationFee;
	}
	public void setActualRegistrationFee(double actualRegistrationFee) {
		this.actualRegistrationFee = actualRegistrationFee;
	}
	
	

}
