package org.cap.game.service;

public class InvalidAgeException extends Exception {
	public InvalidAgeException(String string)
	{
		super(string);
	}

}
