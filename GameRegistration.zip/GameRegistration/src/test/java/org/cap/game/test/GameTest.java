package org.cap.game.test;

import static org.junit.Assert.*;

//import org.cap.account.service.AccountServiceImpl;
import org.cap.game.dao.IGameDao;
import org.cap.game.service.GameServiceImp;
import org.cap.game.service.IGameService;
import org.cap.game.service.InvalidAgeException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.MockitoAnnotations;
import org.mockito.Mock;

public class GameTest {
	
	@Mock
	private IGameDao gameDao;
	private IGameService gameService;
	

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		gameService =new GameServiceImp(gameDao);
	}
	
	@Test(expected=InvalidAgeException.class)
	public void when_Calcluate_actualFees() throws InvalidAgeException
	{
		gameService.calculateActualRegistration(100);
		
	}
	
	@Test(expected=InvalidAgeException.class)
	public void when_Calcluate_actualFees() throws InvalidAgeException
	{
		gameService.calculateActualRegistration(100);
		
	}
	
	

}
