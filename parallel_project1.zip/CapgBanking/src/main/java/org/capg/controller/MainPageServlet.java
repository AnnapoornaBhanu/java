package org.capg.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/MainPageServlet")
public class MainPageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
		
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		HttpSession session=request.getSession();
		
		out.println("<html>"
				+ "<head>"
				+ "<title>MONEY BANK NETBANKING</title>\r\n" + 
				"<link type=\"text/css\" rel=\"stylesheet\" href=\"./styles/mainStyles.css\">"
				+ "</head>"
				+ "<body>\r\n" + 
				"\r\n" + 
				"<div id=\"mainCnt\">\r\n" + 
				"	<div id=\"headDiv\"><h2 align=\"center\" id=\"head\">MONEY BANK NETBANKING</h2></div>\r\n"
				+ "<div class=\"greet\">Hello! "+ session.getAttribute("myUser") +"</div>"  + 
				"	\r\n" +
				"	<ul>\r\n" + 
				"		<li><a href=\"view/createAccount.html\" target=\"mainfrm\">Create Account</a></li>\r\n" + 
				"		<li><a href=\"DepositWithraw\" target=\"mainfrm\">Deposit/withdraw</a></li>\r\n" + 
				"		<li><a href=\"FundsTransferServlet\" target=\"mainfrm\">Fund Transfer</a></li>\r\n" + 
				"		<li><a href=\"#\" target=\"mainfrm\">Transaction Summary</a></li>\r\n" + 
				"		<li><a href=\"./LogoutServlet\" style=\"float:right\">Logout</a></li>\r\n" + 
				"	\r\n" + 
				"	</ul>\r\n" + 
				"	<div id=\"ctrCnt\">\r\n" +  "<br>" +
				"		<iframe name=\"mainfrm\" width=\"1300px\" height=\"375px\" src=\"view/titlePage.html\" ></iframe>\r\n" + 
				"	\r\n" +
				"<div id=\"mySidenav\" class=\"sidenav\">"+
				  "<a href=\"view/About.html\" id=\"about\" target=\"blank\">About</a>"+
				  "<a href=\"#\" id=\"contact\">Contact</a>"+
				"</div> "+
				"	</div>\r\n" + "<br>" +
				"<div id=\"footer\">\r\n" + 
				"<div style=\"float:left;padding-left: 10px;\">Money Banking</div>\r\n" + 
				"<div style=\"margin-left:650px;\">Capgemini-FLP-2018</div>\r\n" + 
				"</div>\r\n" + 
				"</div>\r\n" + 
				"\r\n" + 
				"</body>"
				
				+ "</html>");
		
	
	}

}
