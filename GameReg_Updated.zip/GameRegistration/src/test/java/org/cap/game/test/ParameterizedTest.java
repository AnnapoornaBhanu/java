package org.cap.game.test;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.List;

import org.cap.game.service.GameServiceImp;
import org.cap.game.service.IGameService;
import org.cap.game.service.InvalidAgeException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

@RunWith(Parameterized.class)
public class ParameterizedTest {
	private IGameService gameService=new GameServiceImp();
	private int age;
	private double actualRegFee;
	
	public ParameterizedTest(int age, double actualRegFee) {
		super();
		this.age = age;
		this.actualRegFee = actualRegFee;
	}

	

	@Parameters
	public static List<Object[]> getParameters()
	{
		return Arrays.asList(new Object[][]
				{
				
			{10,1000},
			{18,1100},
			{25,1200},
			{50,1300}
			
				});
	}
	
	@Test
	public void when_calcluate_age() throws InvalidAgeException
	{
		assertEquals(actualRegFee,gameService.calculateActualRegistration(age),0.0);
	}
	
	
}
