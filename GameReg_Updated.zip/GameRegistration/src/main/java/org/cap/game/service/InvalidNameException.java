package org.cap.game.service;

public class InvalidNameException extends Exception {
	
	public InvalidNameException(String string)
	{
		super(string);
	}

}
