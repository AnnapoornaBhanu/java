package org.cap.game.dao;

import org.cap.game.model.Registration;

public interface IGameDao {

		public Registration addCustomer(Registration registration);
}
