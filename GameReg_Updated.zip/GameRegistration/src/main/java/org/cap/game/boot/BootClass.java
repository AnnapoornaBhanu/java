package org.cap.game.boot;

import java.util.Scanner;

import org.apache.log4j.Logger;
import org.cap.game.model.Registration;
import org.cap.game.service.GameServiceImp;
import org.cap.game.service.IGameService;
import org.cap.game.service.InvalidAgeException;
import org.cap.game.service.InvalidMobileNumberException;
import org.cap.game.service.InvalidNameException;
import org.cap.game.view.UserInteraction;

public class BootClass {

	
	public static void main(String[] args) throws InvalidNameException, InvalidMobileNumberException, InvalidAgeException {
		// TODO Auto-generated method stub
		final Logger logger=Logger.getLogger(BootClass.class);
		Scanner scan=new Scanner(System.in);		
		IGameService gameService=new GameServiceImp();
		Registration registration=new Registration();
		UserInteraction userInteraction=new UserInteraction();
		System.out.println("\t\tWelcome to Game Registration");
		System.out.println("\t\t----------------------------");
		String choice;
		do {
		System.out.println("Enter your choice\n1.Register Yourself\t2.Exit");
		int option=scan.nextInt();
		

		switch(option)
		{
		case 1:
			String customerName=userInteraction.promptName();
			String mobileNo=userInteraction.promptMobileNo();
			int age=userInteraction.promptAge();
			double registrationFee=1000;
			double actualRegistrationFee=0;
			
				actualRegistrationFee=gameService.calculateActualRegistration(age);
			
			registration.setCustomerName(customerName);
			registration.setMobileNo(mobileNo);
			registration.setRegistrationFee(registrationFee);
			registration.setActualRegistrationFee(actualRegistrationFee);
			registration.setAge(age);
			
			gameService.addCustomer(registration);
			
			break;
		
		case 2:
			System.exit(0);
			break;
		default:
			System.out.println("Please enter a valid number");
			break;
		}
		System.out.println("Do you want to continue?[y|n]");
		choice=scan.next();
		
		
		}while(choice.charAt(0)=='y'|| choice.charAt(0)=='Y');
		

	}

}
