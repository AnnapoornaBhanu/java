package org.cap.game.service;

import org.cap.game.dao.GameDaoImp;
import org.cap.game.dao.IGameDao;
import org.cap.game.model.Registration;
import org.cap.game.view.UserInteraction;

public class GameServiceImp implements IGameService{
	IGameDao gameDao=new GameDaoImp();
	

	public GameServiceImp(IGameDao gameDao) {
		
		this.gameDao=gameDao;
	}

	public GameServiceImp() {
		
	}

	
	
	//Calculation of Registration Fees based on age group
	@Override
	public double calculateActualRegistration(int age) throws InvalidAgeException {
		
		
		Registration registration=new Registration();
		double actualRegistrationFee;
		double registrationFee=registration.getRegistrationFee();
		if(age>0 && age<18)
		{
			actualRegistrationFee=registrationFee;
		}
		else if(age>=18 && age<25)
		{
			actualRegistrationFee=registrationFee+registrationFee*0.1;
		}
		else if(age>=25 && age<50)
		{
			actualRegistrationFee=registrationFee+registrationFee*0.2;
		}
		else if(age>=50 && age<120)
		{
			actualRegistrationFee=registrationFee+registrationFee*0.3;
		}
		else
		{
			throw new InvalidAgeException("Invalid Age! Not between 0 and 120");
			
		}
		return actualRegistrationFee;

	}

	// If Valid Customer then adds customer details to DB else throws exceptions
	
	@Override
	public void addCustomer(Registration registration) throws InvalidNameException, InvalidMobileNumberException {
		if(registration==null)
		{
			throw new IllegalArgumentException("Invalid Customer!");
		}
		else
		{	
			 if(isValidCustomer(registration))
			 {
				Registration registration1=null;
				registration1=gameDao.addCustomer(registration);
					if(registration1!=null)
						
					{
						UserInteraction userInteraction=new UserInteraction();
						userInteraction.printAcknowledge(registration1);
					}
		}
		}
	
	}

	//Validating customer Name and Mobile number 
	private boolean isValidCustomer(Registration registration) throws InvalidNameException, InvalidMobileNumberException {
		// TODO Auto-generated method stub
		
		boolean name=registration.getCustomerName().matches("[a-zA-z]{3,}");
		boolean mobile=registration.getMobileNo().matches("[7-9]{1}[0-9]{9}");
		if(name==false)
		{
			throw new InvalidNameException("Name can contain only alphabets");
		}
		else
		{
			if(mobile==false)
			{
				throw new InvalidMobileNumberException("Name can contain only alphabets");
			}
			else {
				return true;			}
				
		}
			
		
		
	}
	
	

}
