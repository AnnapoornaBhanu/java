package org.cap.game.view;

import java.util.Scanner;

import org.cap.game.model.Registration;
import org.cap.game.service.GameServiceImp;
import org.cap.game.service.IGameService;
import org.cap.game.util.Utility;

public class UserInteraction {
	static Scanner scan=new Scanner(System.in);
	static IGameService gameService=new GameServiceImp();
	static Utility utility=new Utility();
	public static String promptName()
	{
		//scan.next();
		boolean b=false;
		do {
			
		System.out.println("Enter the name");
		String name=scan.next();
		 b=utility.validateCustomerName(name);
		if(b)
		{
			return name;
		}
		else
		{
			b=false;
			System.out.println("Invalid name! Name can contain only alphabets");
		}
		
		}while(!b);
		
		return null;
		
		
		
	}
	public String promptMobileNo() {
		// TODO Auto-generated method stub
		
		boolean b=false;
		do {
		System.out.println("Enter Mobile Number");
		
		String mobile=scan.next();
		 b=utility.validateMobileNumber(mobile);
		if(b)
		{
			return mobile;
		}
		else
		{
			b=false;
			System.out.println("Invalid name! Mobile Number should be of length 10 digits and must start with 7/8/9");
		}
		}while(!b);
		
		return null;
	}
	public int promptAge() {
		System.out.println("Enter your age");
		int age=scan.nextInt();
		return age;
	}
	public void printAcknowledge(Registration registration1) {
		
		System.out.println("----------------Acknowledgement!----------------------");
		System.out.println("Registration ID: "+registration1.getRegistrationID());
		System.out.println("Congrats! Mr/Mrs. "+registration1.getCustomerName()+" You are successfully registered.");
		System.out.println("Registration Fee Paid: "+registration1.getActualRegistrationFee());
		// TODO Auto-generated method stub
		
	}

}
