package org.cap.game.service;

import org.cap.game.model.Registration;

public interface IGameService {
	
	
	public abstract double calculateActualRegistration(int age) throws InvalidAgeException;
	public abstract void addCustomer(Registration registration) throws InvalidNameException, InvalidMobileNumberException;

}
