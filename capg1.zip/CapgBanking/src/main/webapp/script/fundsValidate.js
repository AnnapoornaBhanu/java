function fundsValidate()
{
	var amount=document.getElementById("amount").value;
	if(amount<=0)
{
				flag=false;
			document.getElementById("err").innerHTML= "Please enter valid amount";
}
			else flag=true;
			return flag;
			}


